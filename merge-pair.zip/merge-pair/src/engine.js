// Merge Pair + Target & Dock engine (pure, shared by simulator and page)
const ENGINE = (() => {
const K = (r,c)=>r*100+c, RC = k=>[Math.floor(k/100), k%100];
const DOCK = 7;

function buildBoard(map){
  const ROWS=map.length, COLS=Math.max(...map.map(r=>r.length));
  const cells=[], isT=new Uint8Array(1200), ADJ=[], EDGES=[];
  map.forEach((row,r)=>[...row].forEach((ch,c)=>{ if(ch!==' '){ cells.push(K(r,c)); isT[K(r,c)]=1; } }));
  for(const k of cells){
    const [r,c]=RC(k), n=[];
    for(const [dr,dc] of [[-1,0],[1,0],[0,-1],[0,1]]){ const rr=r+dr, cc=c+dc; if(rr<0||cc<0||cc>=100) continue; const q=K(rr,cc); if(isT[q]) n.push(q); }
    ADJ[k]=n; for(const q of n) if(q>k) EDGES.push([k,q]);
  }
  const group=new Int16Array(1200).fill(-1); let g=0; const groups=[];
  for(const k of cells){ if(group[k]>=0) continue; const list=[], st=[k]; group[k]=g;
    while(st.length){ const x=st.pop(); list.push(x); for(const y of ADJ[x]) if(group[y]<0){ group[y]=g; st.push(y);} }
    groups.push(list); g++; }
  return {ROWS,COLS,cells,ADJ,EDGES,group,groups};
}
const vec=(a,b)=>[Math.floor(b/100)-Math.floor(a/100),(b%100)-(a%100)];
const dot=(u,v)=>u[0]*v[0]+u[1]*v[1];

function newState(B, level){
  const n=level.beads.length;
  const S={pos:new Int16Array(n), occ:new Int16Array(1200).fill(-1), col:[], inn:[], pid:new Int16Array(n), pieces:[],
    slots:[], queue:level.targets.slice(), dock:[], status:'play', matches:0, moves:0};
  level.beads.forEach((b,i)=>{ S.pos[i]=b.cell; S.occ[b.cell]=i; S.col[i]=b.c; S.inn[i]=b.in||null; });
  S.slots=[{c:S.queue.shift()||null},{c:S.queue.shift()||null}];
  rebuild(B,S);
  return S;
}
function cloneState(S){
  return {pos:S.pos.slice(), occ:S.occ.slice(), col:S.col.slice(), inn:S.inn.slice(), pid:S.pid.slice(), pieces:S.pieces.map(p=>p.slice()),
    slots:S.slots.map(s=>({c:s.c})), queue:S.queue.slice(), dock:S.dock.slice(), status:S.status, matches:S.matches, moves:S.moves};
}
function components(B,S){
  const n=S.pos.length, seen=new Uint8Array(n), out=[];
  for(let i=0;i<n;i++){ if(S.pos[i]<0||seen[i]) continue;
    const comp=[], st=[i]; seen[i]=1;
    while(st.length){ const x=st.pop(); comp.push(x);
      for(const q of B.ADJ[S.pos[x]]){ const y=S.occ[q]; if(y>=0 && !seen[y] && S.col[y]===S.col[x]){ seen[y]=1; st.push(y);} } }
    out.push(comp); }
  return out;
}
function rebuild(B,S){
  S.pieces=[]; S.pid.fill(-1);
  for(const comp of components(B,S)){
    // components are size 1 or 2 here; a larger one (should not persist) is split into singles
    if(comp.length<=2){ const p=S.pieces.length; S.pieces.push(comp); comp.forEach(i=>S.pid[i]=p); }
    else for(const i of comp){ const p=S.pieces.length; S.pieces.push([i]); S.pid[i]=p; }
  }
}

// ---- movement (pos/occ only; pieces fixed during a drag)
function shift(B,S,M,p,lead,target,depth,act){
  if(depth>60) return false;
  act.add(p);
  const ids=S.pieces[p], lc=M.pos[lead];
  const bl=M.occ[target];
  if(bl>=0){ const op=S.pid[bl]; if(op===p) return false;
    if(!vacate(B,S,M,op,bl,vec(lc,target),lc,depth+1,act)) return false; }
  for(const i of ids) M.occ[M.pos[i]]=-1;
  const other=ids.length===2 ? (ids[0]===lead?ids[1]:ids[0]) : -1;
  M.pos[lead]=target; if(other>=0) M.pos[other]=lc;
  for(const i of ids) M.occ[M.pos[i]]=i;
  return true;
}
function vacate(B,S,M,op,hit,d,from,depth,act){
  if(act.has(op)) return false;
  const ids=S.pieces[op];
  let lead, base, ex1, ex2=-1;
  if(ids.length===1){ lead=hit; base=M.pos[hit]; ex1=from; }
  else { lead=ids[0]===hit?ids[1]:ids[0]; base=M.pos[lead]; ex1=M.pos[hit]; ex2=from; }
  const cands=[];
  for(const k of B.ADJ[base]){ if(k===ex1||k===ex2) continue; const s=dot(vec(base,k),d); if(s>=0) cands.push([s,k]); }
  cands.sort((a,b)=>b[0]-a[0]);
  for(const [,k] of cands){
    const T={pos:M.pos.slice(), occ:M.occ.slice()}, a2=new Set(act);
    if(shift(B,S,T,op,lead,k,depth,a2)){ M.pos=T.pos; M.occ=T.occ; for(const x of a2) act.add(x); return true; }
  }
  return false;
}
// one drag step of bead toward neighbour cell N; returns new {pos,occ} or null
function step(B,S,M,bead,N){
  const p=S.pid[bead], ids=S.pieces[p], cell=M.pos[bead];
  const other=ids.length===2 ? (ids[0]===bead?ids[1]:ids[0]) : -1;
  if(other>=0 && M.pos[other]===N){
    const d=vec(cell,N), cands=[];
    for(const k of B.ADJ[N]){ if(k===cell) continue; const s=dot(vec(N,k),d); if(s>=0) cands.push([s,k]); }
    cands.sort((a,b)=>b[0]-a[0]);
    for(const [,k] of cands){ const T={pos:M.pos.slice(),occ:M.occ.slice()}; if(shift(B,S,T,p,other,k,0,new Set())) return T; }
    return null;
  }
  const T={pos:M.pos.slice(),occ:M.occ.slice()};
  return shift(B,S,T,p,bead,N,0,new Set()) ? T : null;
}

// ---- after release
function deliver(S,c,ev){
  const slot=S.slots.find(s=>s.c===c);
  if(slot){
    ev.push({type:'target',c});
    let s=slot; s.c=S.queue.shift()||null;
    // newly active target pulls matching beads from the dock
    let pulled=true;
    while(pulled){ pulled=false;
      for(const t of S.slots){ if(t.c && S.dock.filter(x=>x===t.c).length>=3){
        let n=3; S.dock=S.dock.filter(x=>{ if(x===t.c&&n>0){n--;return false;} return true; });
        ev.push({type:'fromDock',c:t.c}); t.c=S.queue.shift()||null; pulled=true; } }
    }
  } else {
    for(let i=0;i<3;i++){ S.dock.push(c); if(S.dock.length>=DOCK){ S.status='fail'; ev.push({type:'dockFull'}); break; } }
    if(S.status!=='fail') ev.push({type:'dock',c});
  }
  if(S.status==='play' && !S.slots[0].c && !S.slots[1].c) S.status='win';
}
function release(B,S,lastCell,skipStuck){
  const ev=[];
  S.moves++;
  for(;;){
    if(S.status!=='play') break;
    const comps=components(B,S); let hit=null;
    for(const cp of comps) if(cp.length>=3){ hit=cp; break; }
    if(!hit) break;
    const [lr,lc]=RC(lastCell!=null?lastCell:S.pos[hit[0]]);
    hit.sort((a,b)=>{const[ar,ac]=RC(S.pos[a]),[br,bc]=RC(S.pos[b]);return (Math.abs(ar-lr)+Math.abs(ac-lc))-(Math.abs(br-lr)+Math.abs(bc-lc));});
    const three=hit.slice(0,3), c=S.col[three[0]];
    const popped=[];
    for(const i of three){ popped.push({id:i,cell:S.pos[i],c});
      if(S.inn[i]){ S.col[i]=S.inn[i]; S.inn[i]=null; }
      else { S.occ[S.pos[i]]=-1; S.pos[i]=-1; } }
    S.matches++;
    ev.push({type:'pop',c,beads:popped});
    deliver(S,c,ev);
  }
  rebuild(B,S);
  if(!skipStuck && S.status==="play" && !hasAnyMove(B,S)){ S.status='fail'; ev.push({type:'stuck'}); }
  return ev;
}
function hasAnyMove(B,S){
  const M={pos:S.pos,occ:S.occ};
  for(let i=0;i<S.pos.length;i++){ if(S.pos[i]<0) continue; for(const n of B.ADJ[S.pos[i]]) if(step(B,S,M,i,n)) return true; }
  return false;
}
function beadsLeft(S){ let n=0; for(const p of S.pos) if(p>=0) n++; return n; }

return {K,RC,DOCK,buildBoard,newState,cloneState,step,release,components,rebuild,hasAnyMove,beadsLeft,vec,dot};
})();
if(typeof module!=='undefined') module.exports=ENGINE;
