# Merge Pair Levels

Bead track puzzle prototype: **Merge Pair** mechanic combined with **Target & Dock**, plus 10 bot-tested levels.

`index.html` is self-contained: open it in a browser or publish it with GitHub Pages and it runs as is.

## Game rules

- The board is made of tracks. Beads are dragged along the track and push the beads in front of them in the drag direction.
- When a bead is released, same-colored beads that touch each other **merge** and from then on move together. A pair never splits.
- When a third same-colored bead touches the pair, the three **match** and pop.
- **2 Layer Bead:** matches with its outer color. When matched, the outer layer pops and the bead stays in the same slot with its inner color.
- There are **2 active targets**. Each target takes 3 beads (one match).
- A match in a color that is not an active target goes to the **dock**. The dock has 7 slots and each wrong match fills 3 of them. **The level fails when the 7th slot is filled.**
- When a new target becomes active, the 3 beads of that color in the dock automatically fly to the target.
- Win: all targets are completed and the board is cleared. There is no timer in this version.

## Folder structure

```
index.html          Playable page (build output, self-contained)
src/engine.js       Game engine (pure JS, shared by the page and the simulator)
src/page.html       Page template (UI, rendering, input)
levels/levels.json  The 10 levels: track, beads, target order, test result
tools/levels.js     Track layouts, level generator and the 100-play test loop
tools/sim.js        Bot and simulation
tools/drive.js      Re-tests existing levels and regenerates any that fall outside the band
tools/collect.js    Writes test results into levels/levels.json
tools/build.js      Builds index.html from src/ and levels/
```

## Commands

Requires Node.js 18 or newer. There are no dependencies.

```bash
npm run build    # rebuilds index.html from src/ and levels.json
npm run retest   # re-tests all levels with the bot (can take a long time)
npm run levels   # regenerates and tests all levels from scratch (can take a long time)
```

To regenerate or re-test only some levels, pass level indexes starting from 0:

```bash
node tools/levels.js 3 6     # regenerates levels 4 and 7
node tools/collect.js && node tools/build.js
```

## How the levels are made

1. Each level has a track layout and difficulty parameters (number of colors, track fill ratio, 2 layer ratio) in `tools/levels.js`.
2. The generator places the beads:
   - Each color's total count, including 2 layer inner colors, is a multiple of 3 within each track group.
   - No same-colored beads touch at the start.
3. The target order is built so that every next target color has 3 visible beads in one track group. The player is never forced into a wrong match to reach a target.
4. Each level is played 100 times by the bot:
   - The bot first looks for a match into an active target, avoids moves that would send beads to the dock, moves same-colored beads closer together, and makes a random move about 8% of the time.
   - A level is accepted when it fails 35–80 times out of 100.
   - Above 80 fails, the target order is changed first, then the bead layout. If it keeps coming out too hard or too easy, the parameters are adjusted.

| Level | Colors | Beads (2 layer) | Fails out of 100 |
|---|---|---|---|
| 1 Pencere | 5 | 25 (8) | 49 |
| 2 Merdiven | 5 | 30 (12) | 54 |
| 3 Yılan | 6 | 29 (10) | 45 |
| 4 Haç | 6 | 25 (8) | 49 |
| 5 Tarak | 6 | 29 (10) | 52 |
| 6 İki Ada | 6 | 32 (16) | 65 |
| 7 Sarmal | 6 | 32 (10) | 60 |
| 8 H Blok | 6 | 27 (12) | 68 |
| 9 Izgara | 6 | 34 (14) | 42 |
| 10 Kale | 6 | 31 (14) | 42 |

## Level design note

A track loop or a single path without junctions can be unsolvable: beads cannot pass each other, so their order never changes. Every track group needs at least one junction or side branch so beads can change places.
