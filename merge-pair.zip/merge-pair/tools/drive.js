const OUT=require('path').join(__dirname,'..','levels','out'); require('fs').mkdirSync(OUT,{recursive:true});
// retest given levels with the current bot; regenerate any that fall outside 35-80 fails
const {execFileSync}=require('child_process'); const S=require('./sim.js'); const fs=require('fs');
for(const i of process.argv.slice(2).map(Number)){
  let ok=false;
  if(fs.existsSync(`${OUT}/out_${i}.json`)){ const o=JSON.parse(fs.readFileSync(`${OUT}/out_${i}.json`));
    if(o.best){ const w=S.testLevel(o.best,100,4242); const f=100-w; console.error(`L${i+1} retest ${f}`);
      if(f>=35&&f<=80){ o.best.fails=f; o.retest=true; fs.writeFileSync(`${OUT}/out_${i}.json`,JSON.stringify(o)); ok=true; } } }
  if(!ok){ try{ fs.unlinkSync(`${OUT}/out_${i}.json`);}catch(e){} execFileSync('node',[require('path').join(__dirname,'levels.js'),String(i)],{stdio:['ignore','ignore','inherit']}); }
}
