// Builds the self-contained index.html from src/ and levels/levels.json
const fs=require('fs'), path=require('path'); const root=path.join(__dirname,'..');
const eng=fs.readFileSync(path.join(root,'src','engine.js'),'utf8').replace("if(typeof module!=='undefined') module.exports=ENGINE;","");
const levels=JSON.parse(fs.readFileSync(path.join(root,'levels','levels.json'),'utf8')).map(l=>({name:l.name,map:l.map,beads:l.beads,targets:l.targets,fails:l.fails}));
const body=fs.readFileSync(path.join(root,'src','page.html'),'utf8').replace('/*ENGINE*/',eng).replace('/*LEVELS*/',JSON.stringify(levels));
const clean=body.replace(/<meta name="claude:viewport-fit-sides"[^>]*>\n?/,'');
const cut=clean.indexOf('<div class="bar">'); const head=clean.slice(0,cut), main=clean.slice(cut);
const html=`<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<style>:root{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font-size:14px}[hidden]{display:none!important}</style>
${head}</head>
<body>
${main}</body>
</html>
`;
fs.writeFileSync(path.join(root,'index.html'),html); console.log('index.html built');
