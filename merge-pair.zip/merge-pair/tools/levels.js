const OUT=require('path').join(__dirname,'..','levels','out'); require('fs').mkdirSync(OUT,{recursive:true});
const S=require('./sim.js');
const LV=[
 {name:'Pencere', map:["#########","#   #   #","#   #   #","#########","#   #   #","#   #   #","#########"], o:{colors:5,fill:0.65,layer:0.3}},
 {name:'Merdiven', map:["#######","#     #","#######","#     #","#######","#     #","#######","#     #","#######"], o:{colors:5,fill:0.66,layer:0.3}},
 {name:'Yılan', map:["#########","    #   #","#########","#   #    ","#########","    #   #","#########"], o:{colors:6,fill:0.68,layer:0.35}},
 {name:'Haç', map:["  #####  ","  #   #  ","###   ###","#   #   #","#########","#   #   #","###   ###","  #   #  ","  #####  "], o:{colors:6,fill:0.62,layer:0.3}},
 {name:'Tarak', map:["#########","# # # # #","# # # # #","# # # # #","# # # # #","# # # # #","#########"], o:{colors:6,fill:0.7,layer:0.35}},
 {name:'İki Ada', map:["#######  ","#  #  #  ","#######  ","#  #     ","####     ","         ","   ######","   #  # #","   ######","     #  #","     ####"], o:{colors:6,fill:0.62,layer:0.3}},
 {name:'Sarmal', map:["#########","#   #   #","# ##### #","# # # # #","# # ### #","# #   # #","# #######","#   #    ","#########"], o:{colors:6,fill:0.62,layer:0.3}},
 {name:'H Blok', map:["#   #   #","#   #   #","#########","#   #   #","#   #   #","#   #   #","#########","#   #   #","#   #   #"], o:{colors:6,fill:0.64,layer:0.35}},
 {name:'Izgara', map:["#########","# # # # #","#########","# # # # #","#########","# # # # #","#########"], o:{colors:6,fill:0.66,layer:0.35}},
 {name:'Kale', map:["  #####  ","  #   #  ","#########","#   #   #","# ##### #","# #   # #","#########","    #    ","  #####  "], o:{colors:6,fill:0.66,layer:0.35}},
];
module.exports=LV;
if(require.main===module){
  const fs=require('fs');
  const ids=process.argv.slice(2).map(Number);
  for(const i of ids){
    const L=LV[i]; const hist=[]; let best=null; const o={...L.o}; let hard=0, easy=0;
    for(let seed=1; seed<=60 && !best; seed++){
      if(hard>=3){ hard=0; if(o.fill>0.5) o.fill=+(o.fill-0.04).toFixed(2); if(o.layer>0.15) o.layer=+(o.layer-0.05).toFixed(2); if(seed>15&&o.colors>4) o.colors--; process.stderr.write(`L${i+1} easing -> ${JSON.stringify(o)}\n`); }
      if(easy>=3){ easy=0; o.fill=+(o.fill+0.03).toFixed(2); o.layer=+(o.layer+0.05).toFixed(2); process.stderr.write(`L${i+1} hardening -> ${JSON.stringify(o)}\n`); }
      const lv=S.generate(L.map,o,seed*101+i); if(!lv) continue;
      let allHard=true, tooEasy=false;
      for(let ts=0; ts<3 && !best; ts++){
        if(ts>0){ const t2=S.orderTargets(require('../src/engine.js').buildBoard(L.map),lv.beads,S.rng(seed*7+ts)); if(t2) lv.targets=t2; }
        const w20=S.testLevel(lv,20,seed+ts); hist.push({seed,ts,w20});
        if(w20>13){ tooEasy=true; allHard=false; break; }
        if(w20<4) continue;
        allHard=false;
        const w=S.testLevel(lv,100,999+seed); const fails=100-w; hist.push({seed,ts,full:fails});
        if(fails<=80 && fails>=35) best={...lv,fails};
      }
      if(!best){ if(allHard) hard++; if(tooEasy) easy++; }
      process.stderr.write(`L${i+1} seed ${seed} ${JSON.stringify(hist.slice(-2))}\n`);
    }
    fs.writeFileSync(`${OUT}/out_${i}.json`, JSON.stringify({i,name:L.name,best,hist,params:o}));
  }
}
