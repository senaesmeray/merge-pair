// Collects tested results from levels/out into levels/levels.json
const fs=require('fs'), path=require('path');
const LV=require('./levels.js'); const OUT=path.join(__dirname,'..','levels','out'); const FILE=path.join(__dirname,'..','levels','levels.json');
const cur=fs.existsSync(FILE)?JSON.parse(fs.readFileSync(FILE)):[];
const res=LV.map((L,i)=>{ const f=path.join(OUT,`out_${i}.json`);
  if(fs.existsSync(f)){ const o=JSON.parse(fs.readFileSync(f)); if(o.best) return {name:L.name,map:L.map,params:o.params||L.o,beads:o.best.beads,targets:o.best.targets,fails:o.best.fails}; }
  return cur[i]; });
fs.writeFileSync(FILE,JSON.stringify(res,null,1)); console.log('levels.json updated');
