const E = require('../src/engine.js');
const {K,RC,buildBoard,newState,cloneState,step,release,components} = E;

// ---------- seeded rng
function rng(seed){ let s=seed>>>0||1; return ()=>{ s^=s<<13; s>>>=0; s^=s>>17; s^=s<<5; s>>>=0; return s/4294967296; }; }
const shuffle=(a,R)=>{ for(let i=a.length-1;i>0;i--){ const j=Math.floor(R()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; } return a; };

// ---------- bot: enumerate reachable placements per drag
function allMoves(B,S,maxDepth){
  const seen=new Set(), out=[];
  const base={pos:S.pos,occ:S.occ};
  for(let p=0;p<S.pieces.length;p++){
    for(const h of S.pieces[p]){
      let frontier=[base];
      for(let d=0; d<maxDepth && frontier.length; d++){
        const next=[];
        for(const M of frontier){
          for(const n of B.ADJ[M.pos[h]]){
            const M2=step(B,S,M,h,n); if(!M2) continue;
            const key=M2.pos.join(',');
            if(seen.has(key)) continue; seen.add(key);
            out.push({M:M2,h}); next.push(M2);
          }
        }
        frontier=next;
      }
    }
  }
  return out;
}
function evaluate(B,S,mv){
  const T=cloneState(S); T.pos=mv.M.pos; T.occ=mv.M.occ;
  const ev=release(B,T,T.pos[mv.h]>=0?T.pos[mv.h]:null,true);
  let good=0, bad=0;
  for(const e of ev){ if(e.type==='target') good++; if(e.type==='dock') bad++; if(e.type==='dockFull'||e.type==='stuck') bad+=5; }
  // pairs of active colours formed
  let pairs=0; const act=new Set(T.slots.map(s=>s.c).filter(Boolean));
  for(const p of T.pieces) if(p.length===2 && act.has(T.col[p[0]])) pairs++;
  return {T,good,bad,pairs,win:T.status==='win'};
}
function heur(T,cols,w){
  // how far apart beads of each colour are (lower = closer to a match)
  let h=0; const by={};
  for(let i=0;i<T.pos.length;i++){ if(T.pos[i]<0) continue; const c=T.col[i]; (by[c]=by[c]||[]).push(T.pos[i]); }
  for(const c in by){ const wt=cols.has(c)?1:w; if(!wt) continue; const L=by[c]; if(L.length<3) { h+=wt*6; continue; }
    let best=1e9; for(const a of L){ const d=L.filter(b=>b!==a).map(b=>Math.abs(Math.floor(a/100)-Math.floor(b/100))+Math.abs(a%100-b%100)).sort((x,y)=>x-y); best=Math.min(best,d[0]+d[1]); }
    h+=wt*best; }
  return h;
}
function playOnce(B,level,R,opts){
  let S=newState(B,level);
  const mistake=opts.mistake??0.08; let idle=0;
  for(let t=0;t<opts.maxMoves && S.status==='play';t++){
    const moves=allMoves(B,S,opts.depth||6);
    if(!moves.length){ S.status='fail'; break; }
    const evs=moves.map(m=>({m,...evaluate(B,S,m)}));
    let pick;
    if(R()<mistake){ pick=evs[Math.floor(R()*evs.length)]; }
    else {
      const wins=evs.filter(e=>e.win); const A=evs.filter(e=>e.good>0&&e.bad===0);
      const safe=evs.filter(e=>e.bad===0);
      const D=evs.filter(e=>e.bad===1 && e.T.status==='play');
      if(wins.length) pick=wins[0];
      else if(A.length) pick=A[Math.floor(R()*A.length)];
      else if(idle>=8 && D.length){ D.sort((a,b)=>b.good-a.good); pick=D[0].good>0?D[0]:D[Math.floor(R()*D.length)]; }
      else if(safe.length){
        const act=new Set(S.slots.map(x=>x.c).filter(Boolean)); const wOther=idle>=4?0.4:0.1;
        safe.forEach(e=>e.h=heur(e.T,act,wOther)+R()*0.5);
        safe.sort((a,b)=>a.h-b.h); pick=safe[Math.floor(R()*Math.min(3,safe.length))];
      }
      else { evs.sort((a,b)=>a.bad-b.bad); pick=evs[0]; }
    }
    if(pick.good>0||pick.bad>0) idle=0; else idle++;
    S=pick.T;
  }
  LAST.s=S;
  return S.status==='win';
}
const LAST={};
function testLevel(level,n,seed){
  const B=buildBoard(level.map); const R=rng(seed||12345); let w=0;
  for(let i=0;i<n;i++) if(playOnce(B,level,R,{maxMoves:120})) w++;
  return w;
}

// ---------- generator
const PALETTE=['R','Y','B','G','P','O','C','K'];
// target order that never forces a wrong match: each next target colour has 3 visible beads in one track group
function orderTargets(B,beads,R){
  const cur=beads.map(b=>({g:B.group[b.cell],c:b.c,in:b.in,alive:true}));
  const out=[];
  for(;;){
    const left=cur.filter(x=>x.alive); if(!left.length) return out;
    const opts={}; for(const x of left){ const k=x.g+'|'+x.c; opts[k]=(opts[k]||0)+1; }
    const keys=Object.keys(opts).filter(k=>opts[k]>=3); if(!keys.length) return null;
    const k=keys[Math.floor(R()*keys.length)]; const [g,c]=k.split('|');
    let n=3; for(const x of cur){ if(n&&x.alive&&String(x.g)===g&&x.c===c){ n--; if(x.in){ x.c=x.in; x.in=null; } else x.alive=false; } }
    out.push(c);
  }
}
function generate(map,opt,seed){
  const B=buildBoard(map), R=rng(seed);
  const cols=PALETTE.slice(0,opt.colors);
  const beads=[];
  for(const gcells of B.groups){
    const cap=gcells.length;
    let N=Math.round(cap*opt.fill), L=Math.round(N*opt.layer);
    while((N+L)%3) { N--; L=Math.round(N*opt.layer); }
    const units=(N+L)/3;
    // spread units over colours
    const per={}; cols.forEach(c=>per[c]=0);
    const order=shuffle(cols.slice(),R); for(let u=0;u<units;u++) per[order[u%order.length]]++;
    let tokens=[]; for(const c of cols) for(let i=0;i<per[c]*3;i++) tokens.push(c);
    let ok=false, outer, inner;
    for(let tries=0;tries<200&&!ok;tries++){
      shuffle(tokens,R); outer=tokens.slice(0,N); inner=tokens.slice(N);
      ok=true; for(let i=0;i<L;i++) if(inner[i]===outer[i]){ ok=false; break; }
    }
    if(!ok) return null;
    // place without same-colour contact
    let placed=null;
    for(let tries=0;tries<400&&!placed;tries++){
      const cells=shuffle(gcells.slice(),R).slice(0,N); const at={};
      const idx=shuffle([...Array(N).keys()],R);
      let bad=false;
      cells.forEach((k,j)=>at[k]=idx[j]);
      for(const k of cells){ for(const q of B.ADJ[k]) if(at[q]!==undefined && outer[at[q]]===outer[at[k]]) { bad=true; break; } if(bad) break; }
      if(!bad) placed=cells.map(k=>({cell:k,c:outer[at[k]],in:at[k]<L?inner[at[k]]:null}));
    }
    if(!placed) return null;
    beads.push(...placed);
  }
  const targets=orderTargets(B,beads,R);
  if(!targets) return null;
  return {map,beads,targets};
}

module.exports={orderTargets,generate,testLevel,playOnce,rng,shuffle,allMoves,LAST};

if(require.main===module){
  const map=["#########","#   #   #","#   #   #","#########","#   #   #","#   #   #","#########"];
  const lv=generate(map,{colors:5,fill:0.6,layer:0.3},7);
  console.log(lv.beads.length, lv.targets.join(''));
  const t=Date.now(); const w=testLevel(lv,20,1); console.log('wins',w,'/20', (Date.now()-t)+'ms');
}
